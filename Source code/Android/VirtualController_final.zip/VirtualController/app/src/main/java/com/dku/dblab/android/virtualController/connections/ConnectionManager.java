package com.dku.dblab.android.virtualController.connections;

import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

import com.MobileAnarchy.Android.Widgets.Joystick.JoystickMovedListener;
import com.MobileAnarchy.Android.Widgets.Joystick.JoystickView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

/**
 * Created by cobur_000 on 2015-11-23.
 */
public class ConnectionManager {
    private static final HashMap<String, Byte> keyCodes = new HashMap<String, Byte>();
    private static final HashMap<Byte, Byte> keyState = new HashMap<Byte, Byte>();
    private static final byte keyDown = 0;
    private static final byte keyUp = 0x0002;

    static {
        keyCodes.put("Start",(byte)0);
        keyCodes.put("Coin",(byte)1);

        keyCodes.put("Up",(byte)2);
        keyCodes.put("Down",(byte)3);
        keyCodes.put("Left",(byte)4);
        keyCodes.put("Right",(byte)5);

        keyCodes.put("A",(byte)6);
        keyCodes.put("B",(byte)7);
        keyCodes.put("C",(byte)8);
        keyCodes.put("D",(byte)9);
        keyCodes.put("E",(byte)10);
        keyCodes.put("F",(byte)11);

        keyCodes.put("L",(byte)12);
        keyCodes.put("R",(byte)13);

        keyState.put(keyCodes.get("Start"),keyUp);
        keyState.put(keyCodes.get("Coin"),keyUp);

        keyState.put(keyCodes.get("Up"),keyUp);
        keyState.put(keyCodes.get("Down"),keyUp);
        keyState.put(keyCodes.get("Left"),keyUp);
        keyState.put(keyCodes.get("Right"),keyUp);

        keyState.put(keyCodes.get("A"),keyUp);
        keyState.put(keyCodes.get("B"),keyUp);
        keyState.put(keyCodes.get("C"),keyUp);
        keyState.put(keyCodes.get("D"),keyUp);
        keyState.put(keyCodes.get("E"),keyUp);
        keyState.put(keyCodes.get("F"),keyUp);

        keyState.put(keyCodes.get("L"),keyUp);
        keyState.put(keyCodes.get("R"),keyUp);
    }
    private static final int port = 8731;

    private ServerSocket serverSocket;
    private Socket socket;
    private OutputStream os;

    public void dispose()
    {
        new Thread(new Runnable()
        {
            public void run()
            {
                try { serverSocket.close(); }
                catch (Exception e) { }
                try { socket.close(); }
                catch (Exception e) { }
                try { os.close(); }
                catch (Exception e) { }
            }
        }).start();
    }

    public void startUSBConnection()
    {
        new Thread(new Runnable()
        {
            public void run()
            {
                try
                {
                    serverSocket = new ServerSocket(39123);
                    socket = serverSocket.accept();
                    socket.setSendBufferSize(10240);
                    os = socket.getOutputStream();
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public void startWiFiConnection(String ipAddresses)
    {
        final Scanner sc = new Scanner(ipAddresses);

        while(sc.hasNextLine()) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        validate(new Socket(sc.nextLine(), port));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }

    private void validate(Socket soc)
    {
        if (soc != null)
        {
            try
            {
                int validationNumber = new Random().nextInt(1000000000);

                soc.setSoTimeout(2000);

                PrintWriter writer = new PrintWriter(soc.getOutputStream(), true);
                BufferedReader reader = new BufferedReader(new InputStreamReader(soc.getInputStream(), Charset.forName("EUC-KR")));

                writer.println("vc?");
                writer.println(validationNumber);

                String response = reader.readLine();
                int num = Integer.parseInt(reader.readLine());

                if (response.toUpperCase().trim().equals("VC.") && num == ~validationNumber)
                {
                    writer.println("good.");
                    socket = soc;
                    socket.setSendBufferSize(10240);
                    os = socket.getOutputStream();

                    return;
                }
            }
            catch (Exception e)
            {
                try { soc.close(); soc = null; }
                catch (Exception ex) { }

                e.printStackTrace();
            }
        }

        try { soc.close(); soc = null; }
        catch (Exception ex) { }
    }

    private void sendKeyDown(byte keyCode)
    {
        try
        {
            if (keyState.get(keyCode).equals(keyUp))
            {
                keyState.put(keyCode, keyDown);
                os.write(new byte[] { keyDown, keyCode });
            }
        }
        catch (Exception e)
        {
            try { socket.close(); socket = null; }
            catch (Exception ex) { }
        }
    }

    private void sendKeyUp(byte keyCode)
    {
        try
        {
            if (keyState.get(keyCode).equals(keyDown))
            {
                keyState.put(keyCode, keyUp);
                os.write(new byte[] { keyUp, keyCode });
            }
        }
        catch (Exception e)
        {
            try { socket.close(); socket = null; }
            catch (Exception ex) { }
        }
    }

    public JoystickView setOnJostickMovedListener(JoystickView joystick)
    {
        joystick.setOnJostickMovedListener(new JoystickMovedListener()
        {
            public void OnMoved(int pan, int tilt)
            {
                //pan = y, tilt = x
                if (pan >= 8)
                {
                    sendKeyDown(keyCodes.get("Up"));
                }
                else if (pan <= -8)
                {
                    sendKeyDown(keyCodes.get("Down"));
                }
                else
                {
                    sendKeyUp(keyCodes.get("Up"));
                    sendKeyUp(keyCodes.get("Down"));
                }

                if (tilt >= 8)
                {
                    sendKeyDown(keyCodes.get("Right"));
                }
                else if (tilt <= -8)
                {
                    sendKeyDown(keyCodes.get("Left"));
                }
                else
                {
                    sendKeyUp(keyCodes.get("Right"));
                    sendKeyUp(keyCodes.get("Left"));
                }
            }
            public void OnReleased()
            {
                sendKeyUp(keyCodes.get("Up"));
                sendKeyUp(keyCodes.get("Down"));
                sendKeyUp(keyCodes.get("Right"));
                sendKeyUp(keyCodes.get("Left"));
            }
        });

        return joystick;
    }

    public Button setOnButtonTouchListener(Button btn, final String viewName)
    {
        if (!viewName.equals("Joystick"))
        {
            btn.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            sendKeyDown(keyCodes.get(viewName));
                            break;
                        case MotionEvent.ACTION_UP:
                            sendKeyUp(keyCodes.get(viewName));
                            break;
                    }
                    return true;
                }
            });
            btn.setAlpha(0);
        }

        return btn;
    }
}
